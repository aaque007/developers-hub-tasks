import 'package:flutter/material.dart';
import 'user.dart';

class UserProfileScreen extends StatelessWidget {
  final User user;

  UserProfileScreen({required this.user});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(user.name)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            CircleAvatar(
              backgroundImage: NetworkImage(user.profilePicture),
              radius: 50,
            ),
            SizedBox(height: 16),
            Text('Name: ${user.name}', style: TextStyle(fontSize: 20)),
            Text('Email: ${user.email}', style: TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }
}