import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'task_provider.dart';

class TaskScreen extends StatelessWidget {
  final _controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final taskProvider = Provider.of<TaskProvider>(context);
    final tasks = taskProvider.tasks;

    return Scaffold(
      appBar: AppBar(title: Text('Tasks with Provider')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(labelText: 'New Task'),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.add),
                  onPressed: () {
                    if (_controller.text.isNotEmpty) {
                      taskProvider.addTask(_controller.text);
                      _controller.clear();
                    }
                  },
                )
              ],
            ),
          ),
          Expanded(
            child: tasks.isEmpty
                ? Center(child: Text("No tasks added yet!"))
                : ListView.builder(
                    itemCount: tasks.length,
                    itemBuilder: (ctx, i) => Dismissible(
                      key: ValueKey(tasks[i].id),
                      background: Container(color: Colors.red),
                      onDismissed: (_) => taskProvider.removeTask(tasks[i].id),
                      child: ListTile(
                        title: Text(tasks[i].title),
                      ),
                    ),
                  ),
          )
        ],
      ),
    );
  }
}
